
const express = require("express");

const {
    getCrimeStats,
    getCrimes,
    getCrimeAnalytics,
    getCrimeMapLocations,
} = require("../controllers/crimeController");

const router = express.Router();

router.get("/stats", getCrimeStats);

router.get("/analytics", getCrimeAnalytics);


router.get("/map", getCrimeMapLocations);

router.get("/", getCrimes);

module.exports = router;
