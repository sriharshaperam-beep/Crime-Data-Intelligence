// ======================================================
// GET ALL CRIME LOCATIONS FOR THE MAP
// Returns every matching record with valid coordinates.
// ======================================================
const getCrimeMapLocations = async (req, res) => {
    try {
        const { crimeType = "", district = "", date = "" } = req.query;

        const conditions = [
            "latitude IS NOT NULL",
            "longitude IS NOT NULL",
            "latitude BETWEEN -90 AND 90",
            "longitude BETWEEN -180 AND 180",
        ];

        const values = [];

        if (crimeType.trim()) {
            values.push(crimeType.trim());
            conditions.push(`primary_type = $${values.length}`);
        }

        if (district.trim()) {
            const districtNumber = Number(district);

            if (!Number.isFinite(districtNumber)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid district",
                });
            }

            values.push(districtNumber);
            conditions.push(`district = $${values.length}`);
        }

        if (date.trim()) {
            if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid date. Use YYYY-MM-DD.",
                });
            }

            values.push(date);
            conditions.push(`date >= $${values.length}::date`);
            conditions.push(`date < ($${values.length}::date + INTERVAL '1 day')`);
        }

        const result = await pool.query(
            `
            SELECT
                id,
                date,
                primary_type,
                description,
                location_description,
                arrest,
                district,
                latitude,
                longitude
            FROM crimes
            WHERE ${conditions.join(" AND ")}
            ORDER BY id
            `,
            values
        );

        res.set("Cache-Control", "public, max-age=60");

        res.json({
            success: true,
            total: result.rows.length,
            records: result.rows,
        });
    } catch (error) {
        console.error("CRIME MAP ERROR:", error);

        res.status(500).json({
            success: false,
            message: "Failed to fetch crime map locations",
        });
    }
};